/* ============================================================
[LETTER] Letter Engine v2
يعمل مع LETTER_DATABASE.json
4 مستويات x 7 حروف = 28 حرف
Data-driven, Activity Registry
============================================================ */

"use strict";

/* ============================================================
[BOX] تحميل LETTER_DATABASE
============================================================ */

let LETTER_DB = null;
let LETTER_DB_LOADING = false;
let LETTER_DB_LOADED = false;

async function loadLetterDatabase() {
    if (LETTER_DB_LOADED || LETTER_DB_LOADING) return LETTER_DB;
    
    LETTER_DB_LOADING = true;
    
    try {
        const response = await fetch("LETTER_DATABASE.json");
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        LETTER_DB = await response.json();
        LETTER_DB_LOADED = true;
        console.log("[LetterEngine] Database loaded:", LETTER_DB.total_letters || "28 letters");
    } catch (error) {
        console.error("[LetterEngine] Failed to load database:", error);
        LETTER_DB = null;
    }
    
    LETTER_DB_LOADING = false;
    return LETTER_DB;
}

/* ============================================================
[FLOPPY] تتبع التقدم - localStorage key: taha_letters_v2
============================================================ */

const PROGRESS_KEY = "taha_letters_v2";

function getProgress() {
    try {
        const data = localStorage.getItem(PROGRESS_KEY);
        return data ? JSON.parse(data) : createEmptyProgress();
    } catch (e) {
        return createEmptyProgress();
    }
}

function createEmptyProgress() {
    const progress = { levels: {}, completedLevels: [], completedLetters: [] };
    
    if (LETTER_DB && LETTER_DB.levels) {
        LETTER_DB.levels.forEach(level => {
            progress.levels[level.levelId] = {
                completed: false,
                letters: {}
            };
            level.letters.forEach(letter => {
                progress.levels[level.levelId].letters[letter.id] = {
                    completed: false,
                    activities: {},
                    attempts: 0,
                    successes: 0,
                    score: 0,
                    bestTime: null,
                    lastActivity: null,
                    lastDate: null
                };
            });
        });
    }
    
    return progress;
}

function saveProgress(progress) {
    try {
        localStorage.setItem(PROGRESS_KEY, JSON.stringify(progress));
    } catch (e) {
        console.warn("[LetterEngine] Could not save progress:", e);
    }
}

function getLetterProgress(letterId) {
    const progress = getProgress();
    for (const levelId in progress.levels) {
        if (progress.levels[levelId].letters[letterId]) {
            return progress.levels[levelId].letters[letterId];
        }
    }
    return null;
}

function updateLetterProgress(letterId, activityType, isCorrect) {
    const progress = getProgress();
    
    for (const levelId in progress.levels) {
        const level = progress.levels[levelId];
        if (level.letters[letterId]) {
            const letterProg = level.letters[letterId];
            letterProg.attempts++;
            if (isCorrect) {
                letterProg.successes++;
                letterProg.score += 5;
            }
            letterProg.lastActivity = activityType;
            letterProg.lastDate = new Date().toISOString();
            
            if (isCorrect && letterProg.successes >= 1) {
                letterProg.completed = true;
            }
            
            // Check if all activities completed for this letter
            const letterData = getLetterFromDB(letterId);
            if (letterData && letterData.activities) {
                const activityKeys = Object.keys(letterData.activities);
                const completedActivities = activityKeys.filter(
                    key => letterProg.activities[key] && letterProg.activities[key].completed
                );
                if (completedActivities.length >= activityKeys.length && activityKeys.length > 0) {
                    letterProg.completed = true;
                }
            }
            
            // Check if all letters in level completed
            const allCompleted = Object.values(level.letters).every(l => l.completed);
            if (allCompleted) {
                level.completed = true;
                if (!progress.completedLevels.includes(levelId)) {
                    progress.completedLevels.push(levelId);
                }
            }
            
            if (!progress.completedLetters.includes(letterId)) {
                progress.completedLetters.push(letterId);
            }
            
            saveProgress(progress);
            return letterProg;
        }
    }
    
    return null;
}

function recordActivityResult(letterId, activityType, isCorrect, timeSpent) {
    const progress = getProgress();
    
    for (const levelId in progress.levels) {
        if (progress.levels[levelId].letters[letterId]) {
            const letterProg = progress.levels[levelId].letters[letterId];
            letterProg.activities[activityType] = {
                completed: isCorrect,
                attempts: letterProg.attempts,
                timeSpent: timeSpent || 0,
                date: new Date().toISOString()
            };
            saveProgress(progress);
            return letterProg.activities[activityType];
        }
    }
    return null;
}

function getLetterFromDB(letterId) {
    if (!LETTER_DB) return null;
    for (const level of LETTER_DB.levels) {
        const letter = level.letters.find(l => l.id === letterId);
        if (letter) return letter;
    }
    return null;
}

function getLevelFromDB(levelId) {
    if (!LETTER_DB) return null;
    return LETTER_DB.levels.find(l => l.levelId === levelId) || null;
}

/* ============================================================
[ART] محرك عرض واجهة الحروف
============================================================ */

const LetterApp = {
    state: {
        currentView: "levels", // "levels" | "letter" | "activity"
        currentLevelId: null,
        currentLetterId: null,
        currentActivityType: null,
        levelGridExpanded: null // which level card is expanded
    },
    
    /* ---- تنقل ---- */
    
    goToLevels() {
        this.state.currentView = "levels";
        this.state.currentLevelId = null;
        this.state.currentLetterId = null;
        this.state.currentActivityType = null;
        this.render();
    },
    
    goToLevel(levelId) {
        this.state.currentView = "levels";
        this.state.currentLevelId = levelId;
        this.state.levelGridExpanded = levelId;
        this.render();
    },
    
    selectLetter(letterId) {
        const letter = getLetterFromDB(letterId);
        if (!letter) {
            console.warn("[LetterApp] Letter not found:", letterId);
            return;
        }
        
        this.state.currentView = "letter";
        this.state.currentLetterId = letterId;
        this.state.currentActivityType = null;
        this.render();
    },
    
    selectActivity(activityType) {
        this.state.currentActivityType = activityType;
        this.render();
    },
    
    /* ---- الحصول على البيانات ---- */
    
    getLevels() {
        return LETTER_DB ? LETTER_DB.levels : [];
    },
    
    getCurrentLevel() {
        return getLevelFromDB(this.state.currentLevelId);
    },
    
    getCurrentLetter() {
        return getLetterFromDB(this.state.currentLetterId);
    },
    
    getLetterProgress(letterId) {
        return getLetterProgress(letterId);
    },
    
    /* ---- تنفيذ النشاط ---- */
    
    executeActivity(activityType) {
        const letter = this.getCurrentLetter();
        if (!letter) return;
        
        const activity = letter.activities[activityType];
        if (!activity) {
            console.warn("[LetterApp] Activity not found:", activityType);
            return;
        }
        
        // Check if data is verified
        if (letter.content && letter.content.words && letter.content.words.wordsVerified === false) {
            this.showUnverifiedWarning();
            return;
        }
        
        this.state.currentActivityType = activityType;
        this.renderActivity();
    },
    
    /* ---- عرض التحذير ---- */
    
    showUnverifiedWarning() {
        const content = document.getElementById("letterActivityContent");
        if (!content) return;
        
        content.innerHTML = `
            <div class="letter-warning">
                <div class="letter-warning-icon">[WARNING]</div>
                <div class="letter-warning-text">
                    هذه البيانات لم يتم التحقق منها بالكامل من PDF.
                    الكلمات أو الصور موجودة في صور الصفحات فقط.
                </div>
                <button class="secondary" onclick="LetterApp.goToLevels()">رجوع</button>
            </div>
        `;
    },
    
    /* ---- عرض النشاط ---- */
    
    renderActivity() {
        const letter = this.getCurrentLetter();
        const activityType = this.state.currentActivityType;
        const activity = letter.activities[activityType];
        
        const content = document.getElementById("letterActivityContent");
        if (!content) return;
        
        // Check if activity is registered
        const registry = LETTER_DB._activityRegistry;
        if (registry && registry.builtIn && !registry.builtIn[activityType]) {
            content.innerHTML = `
                <div class="letter-activity-notfound">
                    <p>النشاط غير معروف: ${activityType}</p>
                    <button class="secondary" onclick="LetterApp.selectLetter('${letter.id}')">رجوع</button>
                </div>
            `;
            return;
        }
        
        // Build activity content based on type
        switch (activityType) {
            case "maze":
                this.renderMazeActivity(letter, activity);
                break;
            case "traceCircle":
                this.renderTraceCircleActivity(letter, activity);
                break;
            case "connectPictures":
                this.renderConnectPicturesActivity(letter, activity);
                break;
            case "writePractice":
                this.renderWritePracticeActivity(letter, activity);
                break;
            case "learnWords":
                this.renderLearnWordsActivity(letter, activity);
                break;
            default:
                this.renderCustomActivity(letter, activityType);
        }
    },
    
    renderMazeActivity(letter, activity) {
        const content = document.getElementById("letterActivityContent");
        if (!content) return;
        
        const grid = letter.content && letter.content.mazeGrid ? letter.content.mazeGrid : [];
        const targetLetter = letter.id;
        
        if (grid.length === 0) {
            content.innerHTML = `
                <div class="letter-activity-empty">
                    <p>لم تتوفر بيانات المتاهة بعد.</p>
                    <button class="secondary" onclick="LetterApp.selectLetter('${letter.id}')">رجوع</button>
                </div>
            `;
            return;
        }
        
        // Build maze grid as clickable buttons
        const gridCols = Math.ceil(Math.sqrt(grid.length));
        const gridCells = grid.map((cell, index) => {
            const isTarget = cell === targetLetter;
            const isStart = index === 0;
            return `
                <button class="maze-cell ${isTarget ? 'maze-target' : ''} ${isStart ? 'maze-start' : ''}" 
                    data-index="${index}" data-value="${cell}" type="button">
                    ${cell}
                </button>
            `;
        }).join("");
        
        content.innerHTML = `
            <div class="letter-activity-header">
                <h3>[MAZE] ${activity.instruction || "متاهة الحرف"}</h3>
                <p>ابحث عن الحرف <strong>${targetLetter}</strong> في المتاهة</p>
            </div>
            <div class="maze-grid" style="grid-template-columns: repeat(${gridCols}, 1fr);">
                ${gridCells}
            </div>
            <div id="mazeMessage" class="game-message"></div>
            <button class="primary" id="mazeCheckBtn" onclick="LetterApp.checkMazeAnswer('${targetLetter}')" type="button">
                تحقق من الإجابة [OK]
            </button>
            <button class="secondary" onclick="LetterApp.selectLetter('${letter.id}')">رجوع</button>
        `;
    },
    
    renderTraceCircleActivity(letter, activity) {
        const content = document.getElementById("letterActivityContent");
        if (!content) return;
        
        const letters = (activity && activity.letters) || [letter.id];
        const traceLetters = letters.map(l => `
            <span class="trace-letter ${l === letter.id ? 'trace-target' : ''}">${l}</span>
        `).join("");
        
        content.innerHTML = `
            <div class="letter-activity-header">
                <h3>[TARGET] ${activity.instruction || "قم بالشطب على الحرف"}</h3>
                <p>ابحث عن الحرف الصحيح في الدائرة</p>
            </div>
            <div class="trace-circle">
                ${traceLetters}
            </div>
            <p class="trace-instruction">اضغط على الحرف <strong>${letter.id}</strong> للتأكيد</p>
            <button class="primary" onclick="LetterApp.markTraceCorrect('${letter.id}')" type="button">
                هذا هو الحرف الصحيح [OK]
            </button>
            <button class="secondary" onclick="LetterApp.selectLetter('${letter.id}')">رجوع</button>
        `;
    },
    
    renderConnectPicturesActivity(letter, activity) {
        const content = document.getElementById("letterActivityContent");
        if (!content) return;
        
        const words = (letter.content && letter.content.words) ? letter.content.words : [];
        
        if (!words || words.length === 0 || !words.wordsVerified) {
            content.innerHTML = `
                <div class="letter-activity-empty">
                    <p>كلمات الحرف غير متاحة حاليًا.</p>
                    <button class="secondary" onclick="LetterApp.selectLetter('${letter.id}')">رجوع</button>
                </div>
            `;
            return;
        }
        
        const wordList = Array.isArray(words) ? words : [];
        const wordCards = wordList.map((w, i) => `
            <div class="connect-card" data-word-index="${i}">
                <div class="connect-letter">${letter.id}</div>
                <div class="connect-word">${w.word || w}</div>
            </div>
        `).join("");
        
        content.innerHTML = `
            <div class="letter-activity-header">
                <h3>[LINK] ${activity.instruction || "وصل الحرف بالصور"}</h3>
                <p>الحرف <strong>${letter.id}</strong> يبدأ بهذه الكلمات</p>
            </div>
            <div class="connect-pictures">
                ${wordCards}
            </div>
            <button class="secondary" onclick="LetterApp.selectLetter('${letter.id}')">رجوع</button>
        `;
    },
    
    renderWritePracticeActivity(letter, activity) {
        const content = document.getElementById("letterActivityContent");
        if (!content) return;
        
        content.innerHTML = `
            <div class="letter-activity-header">
                <h3>[PENCIL] ${activity.instruction || "أكتب الحرف"}</h3>
                <p>تمرن على كتابة الحرف <strong>${letter.id}</strong></p>
            </div>
            <div class="write-practice">
                <div class="write-target-letter">${letter.id}</div>
                <canvas id="traceCanvas" width="300" height="300" class="trace-canvas"></canvas>
                <p class="write-instruction">ارسم الحرف على الشبكة أعلاه</p>
            </div>
            <button class="secondary" onclick="LetterApp.selectLetter('${letter.id}')">رجوع</button>
        `;
        
        // Initialize trace canvas if available
        this.initTraceCanvas(letter.id);
    },
    
    renderLearnWordsActivity(letter, activity) {
        const content = document.getElementById("letterActivityContent");
        if (!content) return;
        
        const words = (letter.content && letter.content.words) ? letter.content.words : [];
        const wordList = Array.isArray(words) ? words : [];
        
        if (wordList.length === 0) {
            content.innerHTML = `
                <div class="letter-activity-empty">
                    <p>كلمات الحرف غير متاحة حاليًا.</p>
                    <button class="secondary" onclick="LetterApp.selectLetter('${letter.id}')">رجوع</button>
                </div>
            `;
            return;
        }
        
        const wordCards = wordList.map((w, i) => `
            <div class="learn-word-card">
                <div class="learn-word">${w.word || w}</div>
                <div class="learn-word-verified" data-verified="${w.verified}">
                    ${w.verified ? "[OK] موثق" : "[WARNING] غير موثق"}
                </div>
            </div>
        `).join("");
        
        content.innerHTML = `
            <div class="letter-activity-header">
                <h3>[BOOK] ${activity.instruction || "تعرف على الكلمات"}</h3>
                <p>كلمات تبدأ بحرف <strong>${letter.id}</strong></p>
            </div>
            <div class="learn-words-list">
                ${wordCards}
            </div>
            <button class="secondary" onclick="LetterApp.selectLetter('${letter.id}')">رجوع</button>
        `;
    },
    
    renderCustomActivity(letter, activityType) {
        const content = document.getElementById("letterActivityContent");
        if (!content) return;
        
        content.innerHTML = `
            <div class="letter-activity-notfound">
                <p>النشاط "${activityType}" غير متوفر بعد.</p>
                <p>سيتم إضافته قريبًا.</p>
                <button class="secondary" onclick="LetterApp.selectLetter('${letter.id}')">رجوع</button>
            </div>
        `;
    },
    
    /* ---- Canvas tracing ---- */
    
    initTraceCanvas(letterId) {
        const canvas = document.getElementById("traceCanvas");
        if (!canvas) return;
        
        const ctx = canvas.getContext("2d");
        if (!ctx) return;
        
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.strokeStyle = "#3949ab";
        ctx.lineWidth = 4;
        ctx.lineCap = "round";
        ctx.lineJoin = "round";
        
        let isDrawing = false;
        
        const startDrawing = (e) => {
            isDrawing = true;
            const rect = canvas.getBoundingClientRect();
            const x = (e.clientX || e.touches?.[0]?.clientX || 0) - rect.left;
            const y = (e.clientY || e.touches?.[0]?.clientY || 0) - rect.top;
            ctx.beginPath();
            ctx.moveTo(x, y);
        };
        
        const draw = (e) => {
            if (!isDrawing) return;
            const rect = canvas.getBoundingClientRect();
            const x = (e.clientX || e.touches?.[0]?.clientX || 0) - rect.left;
            const y = (e.clientY || e.touches?.[0]?.clientY || 0) - rect.top;
            ctx.lineTo(x, y);
            ctx.stroke();
        };
        
        const stopDrawing = () => {
            isDrawing = false;
            ctx.beginPath();
        };
        
        canvas.addEventListener("mousedown", startDrawing);
        canvas.addEventListener("mousemove", draw);
        canvas.addEventListener("mouseup", stopDrawing);
        canvas.addEventListener("mouseleave", stopDrawing);
        canvas.addEventListener("touchstart", (e) => { e.preventDefault(); startDrawing(e); });
        canvas.addEventListener("touchmove", (e) => { e.preventDefault(); draw(e); });
        canvas.addEventListener("touchend", stopDrawing);
    },
    
    /* ---- التحقق من الإجابات ---- */
    
    checkMazeAnswer(targetLetter) {
        const cells = document.querySelectorAll(".maze-cell");
        const selectedCells = document.querySelectorAll(".maze-cell.selected");
        const message = document.getElementById("mazeMessage");
        
        if (selectedCells.length === 0) {
            if (message) message.textContent = "اضغط على مربعات المتاهة لتحديد المسار";
            return;
        }
        
        const path = Array.from(selectedCells).map(btn => btn.dataset.value);
        const found = path.includes(targetLetter);
        
        if (message) {
            message.textContent = found ? "[CHEER] أحسنت! وجدت الحرف!" : "[SMILE] حاول مرة أخرى";
            message.style.color = found ? "#22c55e" : "#333";
        }
        
        if (found) {
            updateLetterProgress(targetLetter, "maze", true);
        }
    },
    
    markTraceCorrect(letterId) {
        updateLetterProgress(letterId, "traceCircle", true);
        
        const content = document.getElementById("letterActivityContent");
        if (content) {
            content.innerHTML += `
                <div class="trace-result">
                    <p>[CHEER] ممتاز! شطبت الحرف بنجاح!</p>
                </div>
            `;
        }
    },
    
    /* ---- العرض الرئيسي ---- */
    
    render() {
        // Clear and render based on current view
        const container = document.getElementById("letterEngineContainer");
        if (!container) return;
        
        if (this.state.currentView === "levels") {
            this.renderLevelGrid(container);
        } else if (this.state.currentView === "letter") {
            this.renderLetterDetail(container);
        } else if (this.state.currentView === "activity") {
            this.renderLetterDetail(container);
        }
    },
    
    renderLevelGrid(container) {
        const levels = this.getLevels();
        const progress = getProgress();
        
        let html = `
            <div class="letters-engine">
                <div class="letters-header">
                    <h2>[LETTER] الحروف</h2>
                    <div class="letters-progress-summary">
                        <span>مكتمل: <strong>${progress.completedLetters.length}</strong> / ${LETTER_DB ? LETTER_DB.total_letters : 28}</span>
                    </div>
                </div>
                <div class="levels-grid">
        `;
        
        levels.forEach(level => {
            const levelProg = progress.levels[level.levelId];
            const levelCompleted = levelProg && levelProg.completed;
            const lettersInLevel = level.letters;
            const completedInLevel = lettersInLevel.filter(l => {
                const lp = levelProg && levelProg.letters[l.id];
                return lp && lp.completed;
            }).length;
            
            const levelLettersHtml = lettersInLevel.map(l => {
                const lp = levelProg && levelProg.letters[l.id];
                const letterCompleted = lp && lp.completed;
                const letterScore = lp ? lp.score : 0;
                return `
                    <button class="letter-card ${letterCompleted ? 'letter-completed' : ''}" 
                        onclick="LetterApp.selectLetter('${l.id}')"
                        type="button"
                        aria-label="حرف ${l.id}">
                        <div class="letter-card-letter">${l.id}</div>
                        <div class="letter-card-name">${l.name}</div>
                        ${letterCompleted ? '<div class="letter-card-check">[OK]</div>' : ''}
                        ${letterScore > 0 ? `<div class="letter-card-score">[STAR] ${letterScore}</div>` : ''}
                    </button>
                `;
            }).join("");
            
            html += `
                <div class="level-card ${levelCompleted ? 'level-completed' : ''}">
                    <div class="level-card-header" onclick="LetterApp.goToLevel('${level.levelId}')">
                        <h3>${level.levelName}</h3>
                        ${levelCompleted ? '<span class="level-check">[CROWN]</span>' : ''}
                    </div>
                    <div class="level-card-progress">
                        <div class="progress-bar">
                            <div class="progress-fill" style="width:${lettersInLevel.length > 0 ? (completedInLevel / lettersInLevel.length * 100) : 0}%"></div>
                        </div>
                        <span>${completedInLevel} / ${lettersInLevel.length}</span>
                    </div>
                    <div class="level-card-letters">
                        ${levelLettersHtml}
                    </div>
                </div>
            `;
        });
        
        html += `
                </div>
                <button class="primary home-btn" onclick="showScreen('home')">[HOME] الرئيسية</button>
            </div>
        `;
        
        container.innerHTML = html;
    },
    
    renderLetterDetail(container) {
        const letter = this.getCurrentLetter();
        if (!letter) return;
        
        const letterProg = this.getLetterProgress(letter.id);
        const level = this.getCurrentLevel();
        
        let html = `
            <div class="letter-detail">
                <div class="letter-detail-header">
                    <button class="secondary back-btn" onclick="LetterApp.goToLevels()">[BACK] رجوع</button>
                    <h2>حرف ${letter.id}</h2>
                </div>
                
                <div class="letter-detail-main">
                    <!-- الحرف الكبير -->
                    <div class="letter-detail-big">
                        <div class="big-letter-display">${letter.id}</div>
                        <div class="letter-name-display">${letter.name}</div>
                    </div>
                    
                    <!-- صوت الحرف -->
                    <div class="letter-detail-audio">
                        <button class="audio-btn" onclick="LetterApp.playLetterAudio('${letter.id}')" type="button">
                            [SPEAKER] صوت الحرف
                        </button>
                        <div class="audio-status">${letter.audio && letter.audio.source ? "[OK] جاهز" : "[HOURGLASS] قيد الإعداد"}</div>
                    </div>
                    
                    <!-- المعلومات -->
                    <div class="letter-detail-info">
                        <p><strong>الاسم:</strong> ${letter.name}</p>
                        <p><strong>الفتحة:</strong> ${letter.fathaOnly}</p>
                        
                        <!-- أشكال الحرف -->
                        <div class="letter-forms">
                            <h4>أشكال الحرف</h4>
                            <div class="forms-grid">
                                <div class="form-item">
                                    <span class="form-label">معزول</span>
                                    <span class="form-value">${this.getFormDisplay(letter, 'isolated')}</span>
                                </div>
                                ${letter.forms && letter.forms.initial ? `
                                <div class="form-item">
                                    <span class="form-label">أول</span>
                                    <span class="form-value">${this.getFormDisplay(letter, 'initial')}</span>
                                </div>` : ''}
                                ${letter.forms && letter.forms.medial ? `
                                <div class="form-item">
                                    <span class="form-label">أوسط</span>
                                    <span class="form-value">${this.getFormDisplay(letter, 'medial')}</span>
                                </div>` : ''}
                                ${letter.forms && letter.forms.final ? `
                                <div class="form-item">
                                    <span class="form-label">أخير</span>
                                    <span class="form-value">${this.getFormDisplay(letter, 'final')}</span>
                                </div>` : ''}
                            </div>
                        </div>
                        
                        ${letter.connectRules ? `
                        <div class="letter-connect-info">
                            <h4>قاعدة الاتصال</h4>
                            <p>${letter.connectRules.note || this.getConnectRuleText(letter)}</p>
                        </div>
                        ` : ''}
                    </div>
                </div>
                
                <!-- الأنشطة -->
                <div class="letter-detail-activities">
                    <h3>الأنشطة المتاحة</h3>
                    <div class="activities-list">
        `;
        
        if (letter.activities) {
            const activityTypes = Object.keys(letter.activities);
            activityTypes.forEach(activityType => {
                const activity = letter.activities[activityType];
                const prog = letterProg && letterProg.activities && letterProg.activities[activityType];
                const isCompleted = prog && prog.completed;
                const registryLabel = (LETTER_DB._activityRegistry && LETTER_DB._activityRegistry.builtIn && LETTER_DB._activityRegistry.builtIn[activityType])
                    ? LETTER_DB._activityRegistry.builtIn[activityType].label
                    : activityType;
                
                html += `
                    <button class="activity-card ${isCompleted ? 'activity-completed' : ''}" 
                        onclick="LetterApp.selectActivity('${activityType}')"
                        type="button">
                        <span class="activity-name">${registryLabel}</span>
                        ${isCompleted ? '[OK]' : '[HOURGLASS]'}
                    </button>
                `;
            });
        }
        
        html += `
                    </div>
                </div>
                
                <!-- التقدم -->
                <div class="letter-detail-progress">
                    <h3>تقدمك</h3>
                    <div class="progress-details">
                        <p>المحاولات: <strong>${letterProg ? letterProg.attempts : 0}</strong></p>
                        <p>النجاحات: <strong>${letterProg ? letterProg.successes : 0}</strong></p>
                        <p>النقاط: <strong>${letterProg ? letterProg.score : 0}</strong></p>
                        ${letterProg && letterProg.lastActivity ? `<p>آخر نشاط: ${letterProg.lastActivity}</p>` : ''}
                    </div>
                </div>
                
                <!-- محتوى النشاط -->
                <div id="letterActivityContent"></div>
                
                <button class="secondary" onclick="LetterApp.goToLevels()">[HOME] المستويات</button>
            </div>
        `;
        
        container.innerHTML = html;
    },
    
    getFormDisplay(letter, formType) {
        if (!letter.forms) return letter.id;
        const form = letter.forms[formType];
        if (form) return form;
        if (form === null || form === undefined) return "—";
        return letter.id;
    },
    
    getConnectRuleText(letter) {
        if (!letter.connectRules) return "";
        if (letter.connectRules.canConnectLeft && letter.connectRules.canConnectRight) {
            return "يتصل من الجانبين (كل الأشكال متاحة)";
        } else if (letter.connectRules.canConnectRight && !letter.connectRules.canConnectLeft) {
            return "يتصل يمينًا فقط (لا يتصل بالحرف السابق)";
        } else if (!letter.connectRules.canConnectLeft && !letter.connectRules.canConnectRight) {
            return "لا يتصل بأي حرف (شكل معزول فقط)";
        }
        return "حرف عادي";
    },
    
    playLetterAudio(letterId) {
        const letter = getLetterFromDB(letterId);
        if (!letter) return;
        
        // Check if audio exists
        if (letter.audio && letter.audio.source && letter.audio.filePath) {
            // Play actual audio file
            const audio = new Audio(letter.audio.filePath);
            audio.play().catch(() => {});
        } else if (letter.audio && letter.audio.fatha) {
            // Use existing audio data
            const audio = new Audio(letter.audio.fatha);
            audio.play().catch(() => {});
        } else {
            // Audio not available yet
            const content = document.getElementById("letterActivityContent");
            if (content) {
                const existing = content.querySelector(".audio-notice");
                if (!existing) {
                    const notice = document.createElement("div");
                    notice.className = "audio-notice";
                    notice.textContent = "[MUTE] الصوت قيد الإعداد. سيتم إضافة تسجيلات الحرف لاحقًا.";
                    content.insertBefore(notice, content.firstChild);
                }
            }
            
            // Fallback: use speechSynthesis for now (not final solution)
            const fathaText = letter.fathaOnly || letter.id;
            speak(fathaText, { rate: 0.75 });
        }
    }
};

/* ============================================================
[GLOBAL] دالة التنقل إلى شاشة الحروف الجديدة
============================================================ */

function showLettersEngine() {
    // Hide old letters section, show new engine
    const oldLetters = document.getElementById("letters");
    const newEngine = document.getElementById("letters-engine");
    
    if (oldLetters) oldLetters.style.display = "none";
    if (newEngine) newEngine.style.display = "block";
    
    // Load database and render
    loadLetterDatabase().then(() => {
        LetterApp.goToLevels();
    });
}

/* ============================================================
[WRENCH] تهيئة عند تحميل الصفحة
============================================================ */

document.addEventListener("DOMContentLoaded", function() {
    // Create the letters-engine section if not exists
    // It should already exist in the HTML
    const engineSection = document.getElementById("letters-engine");
    if (engineSection) {
        engineSection.style.display = "none"; // Hidden by default, shown via showLettersEngine()
    }
});

// Make LetterApp globally accessible
window.LetterApp = LetterApp;
window.loadLetterDatabase = loadLetterDatabase;
window.showLettersEngine = showLettersEngine;
